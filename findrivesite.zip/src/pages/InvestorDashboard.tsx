import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Logo from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Wallet, PieChart, Settings, LogOut, Bell, BarChart3, Clock, ArrowUpRight } from "lucide-react";

const mockPortfolio = [
  { id: 1, company: "ООО «ТехноПром»", amount: 150000, rate: 22.5, term: "12 мес", status: "Активный" },
  { id: 2, company: "ООО «СтройМаркет»", amount: 80000, rate: 19.8, term: "24 мес", status: "Активный" },
  { id: 3, company: "АО «ЛогистикПлюс»", amount: 200000, rate: 21.0, term: "18 мес", status: "Активный" },
  { id: 4, company: "ООО «ФудСервис»", amount: 50000, rate: 24.2, term: "6 мес", status: "Завершён" },
];

const InvestorDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");

  const totalInvested = mockPortfolio.reduce((s, p) => s + p.amount, 0);
  const avgRate = (mockPortfolio.reduce((s, p) => s + p.rate, 0) / mockPortfolio.length).toFixed(1);

  return (
    <div className="min-h-screen bg-section-alt">
      <header className="bg-background border-b sticky top-0 z-50">
        <div className="container flex items-center justify-between h-14">
          <Logo size="sm" />
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon"><Bell size={18} /></Button>
            <Button variant="ghost" size="icon"><Settings size={18} /></Button>
            <Button variant="ghost" size="icon" onClick={() => navigate("/login")}><LogOut size={18} /></Button>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <h1 className="text-2xl font-heading font-bold mb-6">Личный кабинет инвестора</h1>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Wallet, label: "Баланс", value: "124 500 ₽", color: "text-primary" },
            { icon: TrendingUp, label: "Инвестировано", value: `${totalInvested.toLocaleString("ru-RU")} ₽`, color: "text-primary" },
            { icon: PieChart, label: "Средняя ставка", value: `${avgRate}%`, color: "text-primary" },
            { icon: BarChart3, label: "Доход за месяц", value: "8 240 ₽", color: "text-primary" },
          ].map((s) => (
            <Card key={s.label}>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
                    <s.icon className={s.color} size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{s.label}</p>
                    <p className="text-xl font-heading font-bold">{s.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto">
          {["overview", "portfolio", "available"].map((tab) => (
            <Button
              key={tab}
              variant={activeTab === tab ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab(tab)}
            >
              {tab === "overview" ? "Обзор" : tab === "portfolio" ? "Портфель" : "Доступные займы"}
            </Button>
          ))}
        </div>

        {activeTab === "overview" && (
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader><CardTitle className="text-lg font-heading">Последние инвестиции</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockPortfolio.slice(0, 3).map((p) => (
                    <div key={p.id} className="flex items-center justify-between p-3 rounded-lg bg-section-alt">
                      <div>
                        <p className="font-medium text-sm">{p.company}</p>
                        <p className="text-xs text-muted-foreground">{p.term} • {p.rate}%</p>
                      </div>
                      <p className="font-heading font-bold">{p.amount.toLocaleString("ru-RU")} ₽</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="text-lg font-heading">Ближайшие выплаты</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { date: "15 апр", amount: "12 500 ₽", company: "ООО «ТехноПром»" },
                    { date: "22 апр", amount: "5 800 ₽", company: "ООО «СтройМаркет»" },
                    { date: "01 май", amount: "15 200 ₽", company: "АО «ЛогистикПлюс»" },
                  ].map((p, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-section-alt">
                      <div className="flex items-center gap-3">
                        <Clock size={16} className="text-muted-foreground" />
                        <div>
                          <p className="font-medium text-sm">{p.company}</p>
                          <p className="text-xs text-muted-foreground">{p.date}</p>
                        </div>
                      </div>
                      <p className="font-heading font-bold text-primary">{p.amount}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "portfolio" && (
          <Card>
            <CardHeader><CardTitle className="text-lg font-heading">Мой портфель</CardTitle></CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 font-medium text-muted-foreground">Компания</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Сумма</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Ставка</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Срок</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Статус</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockPortfolio.map((p) => (
                      <tr key={p.id} className="border-b last:border-0">
                        <td className="py-3 font-medium">{p.company}</td>
                        <td className="py-3 text-right">{p.amount.toLocaleString("ru-RU")} ₽</td>
                        <td className="py-3 text-right text-primary font-medium">{p.rate}%</td>
                        <td className="py-3 text-right">{p.term}</td>
                        <td className="py-3 text-right">
                          <span className={`px-2 py-0.5 rounded-full text-xs ${p.status === "Активный" ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"}`}>
                            {p.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === "available" && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { company: "ООО «МедТех»", amount: "5 000 000 ₽", rate: "20.1%", term: "12 мес", filled: 67 },
              { company: "ООО «АгроСнаб»", amount: "3 200 000 ₽", rate: "22.8%", term: "18 мес", filled: 45 },
              { company: "АО «ДигиталПро»", amount: "8 000 000 ₽", rate: "18.5%", term: "24 мес", filled: 82 },
              { company: "ООО «ЭкоПак»", amount: "1 500 000 ₽", rate: "24.0%", term: "6 мес", filled: 23 },
            ].map((loan, i) => (
              <Card key={i} className="hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-3">
                    <p className="font-heading font-semibold">{loan.company}</p>
                    <ArrowUpRight size={16} className="text-muted-foreground" />
                  </div>
                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex justify-between"><span className="text-muted-foreground">Сумма</span><span className="font-medium">{loan.amount}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Ставка</span><span className="font-medium text-primary">{loan.rate}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Срок</span><span className="font-medium">{loan.term}</span></div>
                  </div>
                  <div className="mb-3">
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-muted-foreground">Собрано</span>
                      <span>{loan.filled}%</span>
                    </div>
                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${loan.filled}%` }} />
                    </div>
                  </div>
                  <Button size="sm" className="w-full">Инвестировать</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default InvestorDashboard;
