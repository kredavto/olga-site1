import { useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import Logo from "@/components/Logo";

const RegisterPage = () => {
  const [searchParams] = useSearchParams();
  const defaultRole = searchParams.get("role") || "investor";
  const [role, setRole] = useState<string>(defaultRole);
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", confirmPassword: "", company: "", inn: "" });
  const navigate = useNavigate();
  const { toast } = useToast();

  const update = (field: string, value: string) => setForm({ ...form, [field]: value });

  const handleStep1 = () => {
    if (!form.name || !form.email || !form.phone || !form.password) {
      toast({ title: "Ошибка", description: "Заполните все обязательные поля", variant: "destructive" });
      return;
    }
    if (form.password !== form.confirmPassword) {
      toast({ title: "Ошибка", description: "Пароли не совпадают", variant: "destructive" });
      return;
    }
    if (form.password.length < 8) {
      toast({ title: "Ошибка", description: "Пароль должен быть не менее 8 символов", variant: "destructive" });
      return;
    }
    setStep(2);
  };

  const handleStep2 = () => {
    if (role === "borrower" && (!form.company || !form.inn)) {
      toast({ title: "Ошибка", description: "Заполните данные компании", variant: "destructive" });
      return;
    }
    setStep(3);
  };

  const handleFinish = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: {
        data: {
          full_name: form.name,
          role: role,
          phone: form.phone,
          company: role === "borrower" ? form.company : null,
          inn: role === "borrower" ? form.inn : null,
        },
      },
    });
    setLoading(false);

    if (error) {
      toast({ title: "Ошибка регистрации", description: error.message, variant: "destructive" });
      return;
    }

    toast({ title: "Регистрация завершена!", description: "Добро пожаловать в «ФИНДРАЙВ»" });
    navigate("/setup-2fa", { state: { role } });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-section-alt p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <Logo size="md" className="justify-center mb-4" />
          <CardTitle className="font-heading">Регистрация</CardTitle>
          <CardDescription>Шаг {step} из 3</CardDescription>
        </CardHeader>
        <CardContent>
          {step === 1 && (
            <div className="space-y-4">
              <Tabs value={role} onValueChange={setRole}>
                <TabsList className="grid grid-cols-2 w-full">
                  <TabsTrigger value="investor">Инвестор</TabsTrigger>
                  <TabsTrigger value="borrower">Заёмщик</TabsTrigger>
                </TabsList>
              </Tabs>

              <div className="space-y-3">
                <div>
                  <Label>ФИО *</Label>
                  <Input value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Иванов Иван Иванович" />
                </div>
                <div>
                  <Label>Email *</Label>
                  <Input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="ivan@mail.ru" />
                </div>
                <div>
                  <Label>Телефон *</Label>
                  <Input type="tel" value={form.phone} onChange={(e) => update("phone", e.target.value)} placeholder="+7 (999) 123-45-67" />
                </div>
                <div>
                  <Label>Пароль *</Label>
                  <Input type="password" value={form.password} onChange={(e) => update("password", e.target.value)} placeholder="Минимум 8 символов" />
                </div>
                <div>
                  <Label>Подтвердите пароль *</Label>
                  <Input type="password" value={form.confirmPassword} onChange={(e) => update("confirmPassword", e.target.value)} />
                </div>
              </div>
              <Button className="w-full" onClick={handleStep1}>Далее</Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              {role === "borrower" ? (
                <div className="space-y-3">
                  <div>
                    <Label>Название компании *</Label>
                    <Input value={form.company} onChange={(e) => update("company", e.target.value)} placeholder="ООО «Компания»" />
                  </div>
                  <div>
                    <Label>ИНН *</Label>
                    <Input value={form.inn} onChange={(e) => update("inn", e.target.value)} placeholder="1234567890" />
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Как инвестор, вы сможете инвестировать в кредиты для бизнеса и получать доход.
                  </p>
                  <div className="bg-accent rounded-lg p-4">
                    <p className="text-sm text-accent-foreground font-medium">Минимальная сумма инвестиций: 1 000 ₽</p>
                    <p className="text-sm text-accent-foreground">Средняя доходность: 18-22% годовых</p>
                  </div>
                </div>
              )}
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={() => setStep(1)}>Назад</Button>
                <Button className="flex-1" onClick={handleStep2}>Далее</Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div className="bg-accent rounded-lg p-4 space-y-2">
                <p className="font-heading font-semibold">Подтвердите данные</p>
                <p className="text-sm"><span className="text-muted-foreground">Тип аккаунта:</span> {role === "investor" ? "Инвестор" : "Заёмщик"}</p>
                <p className="text-sm"><span className="text-muted-foreground">ФИО:</span> {form.name}</p>
                <p className="text-sm"><span className="text-muted-foreground">Email:</span> {form.email}</p>
                <p className="text-sm"><span className="text-muted-foreground">Телефон:</span> {form.phone}</p>
                {role === "borrower" && (
                  <>
                    <p className="text-sm"><span className="text-muted-foreground">Компания:</span> {form.company}</p>
                    <p className="text-sm"><span className="text-muted-foreground">ИНН:</span> {form.inn}</p>
                  </>
                )}
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={() => setStep(2)}>Назад</Button>
                <Button className="flex-1" onClick={handleFinish} disabled={loading}>
                  {loading ? "Регистрация..." : "Зарегистрироваться"}
                </Button>
              </div>
            </div>
          )}

          <p className="text-center text-sm text-muted-foreground mt-6">
            Уже есть аккаунт?{" "}
            <Link to="/login" className="text-primary hover:underline font-medium">Войти</Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default RegisterPage;
