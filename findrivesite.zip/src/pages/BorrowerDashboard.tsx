import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Logo from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Wallet, TrendingDown, CreditCard, Settings, LogOut, Bell, FileText, Clock, CheckCircle } from "lucide-react";

const BorrowerDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="min-h-screen bg-section-alt">
      <header className="bg-background border-b sticky top-0 z-50">
        <div className="container flex items-center justify-between h-14">
          <Logo size="sm" />
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon"><Bell size={18} /></Button>
            <Button variant="ghost" size="icon"><Settings size={18} /></Button>
            <Button variant="ghost" size="icon" onClick={() => navigate("/login")}><LogOut size={18} /></Button>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <h1 className="text-2xl font-heading font-bold mb-6">Личный кабинет заёмщика</h1>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { icon: CreditCard, label: "Одобренный лимит", value: "15 000 000 ₽" },
            { icon: TrendingDown, label: "Текущий долг", value: "4 250 000 ₽" },
            { icon: Wallet, label: "Доступно", value: "10 750 000 ₽" },
            { icon: Clock, label: "След. платёж", value: "156 800 ₽" },
          ].map((s) => (
            <Card key={s.label}>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
                    <s.icon className="text-primary" size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{s.label}</p>
                    <p className="text-xl font-heading font-bold">{s.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto">
          {["overview", "loans", "documents"].map((tab) => (
            <Button
              key={tab}
              variant={activeTab === tab ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab(tab)}
            >
              {tab === "overview" ? "Обзор" : tab === "loans" ? "Мои займы" : "Документы"}
            </Button>
          ))}
        </div>

        {activeTab === "overview" && (
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader><CardTitle className="text-lg font-heading">Активные транши</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                {[
                  { id: "T-001", amount: "2 500 000 ₽", rate: "19.2%", due: "15.10.2026", paid: 35 },
                  { id: "T-002", amount: "1 750 000 ₽", rate: "20.5%", due: "22.06.2026", paid: 58 },
                ].map((t) => (
                  <div key={t.id} className="p-4 rounded-lg border">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <p className="font-heading font-semibold">{t.id}</p>
                        <p className="text-sm text-muted-foreground">{t.amount} • {t.rate}</p>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-xs bg-accent text-accent-foreground">Активный</span>
                    </div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-muted-foreground">Погашено</span>
                      <span>{t.paid}%</span>
                    </div>
                    <Progress value={t.paid} className="h-2" />
                    <p className="text-xs text-muted-foreground mt-2">Срок до: {t.due}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="text-lg font-heading">График платежей</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { date: "15 апр 2026", amount: "156 800 ₽", status: "upcoming" },
                    { date: "15 мар 2026", amount: "156 800 ₽", status: "paid" },
                    { date: "15 фев 2026", amount: "156 800 ₽", status: "paid" },
                    { date: "15 янв 2026", amount: "156 800 ₽", status: "paid" },
                  ].map((p, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-section-alt">
                      <div className="flex items-center gap-3">
                        {p.status === "paid" ? (
                          <CheckCircle size={16} className="text-primary" />
                        ) : (
                          <Clock size={16} className="text-muted-foreground" />
                        )}
                        <div>
                          <p className="font-medium text-sm">{p.date}</p>
                          <p className="text-xs text-muted-foreground">
                            {p.status === "paid" ? "Оплачено" : "Предстоящий"}
                          </p>
                        </div>
                      </div>
                      <p className="font-heading font-bold">{p.amount}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardContent className="pt-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div>
                    <h3 className="font-heading font-semibold text-lg">Запросить новый транш</h3>
                    <p className="text-sm text-muted-foreground">Доступно: 10 750 000 ₽ в рамках одобренного лимита</p>
                  </div>
                  <Button size="lg">Запросить транш</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "loans" && (
          <Card>
            <CardHeader><CardTitle className="text-lg font-heading">История займов</CardTitle></CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 font-medium text-muted-foreground">ID</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Сумма</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Ставка</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Дата</th>
                      <th className="text-right py-3 font-medium text-muted-foreground">Статус</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { id: "T-001", amount: "2 500 000 ₽", rate: "19.2%", date: "15.10.2025", status: "Активный" },
                      { id: "T-002", amount: "1 750 000 ₽", rate: "20.5%", date: "22.06.2025", status: "Активный" },
                      { id: "T-003", amount: "3 000 000 ₽", rate: "21.0%", date: "01.01.2025", status: "Погашен" },
                    ].map((l) => (
                      <tr key={l.id} className="border-b last:border-0">
                        <td className="py-3 font-medium">{l.id}</td>
                        <td className="py-3 text-right">{l.amount}</td>
                        <td className="py-3 text-right text-primary font-medium">{l.rate}</td>
                        <td className="py-3 text-right">{l.date}</td>
                        <td className="py-3 text-right">
                          <span className={`px-2 py-0.5 rounded-full text-xs ${l.status === "Активный" ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"}`}>
                            {l.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === "documents" && (
          <Card>
            <CardHeader><CardTitle className="text-lg font-heading">Документы</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: "Договор займа T-001", date: "15.10.2025", type: "PDF" },
                  { name: "Договор займа T-002", date: "22.06.2025", type: "PDF" },
                  { name: "График платежей T-001", date: "15.10.2025", type: "PDF" },
                  { name: "Акт сверки за 2025", date: "01.01.2026", type: "PDF" },
                ].map((doc, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <FileText size={18} className="text-muted-foreground" />
                      <div>
                        <p className="font-medium text-sm">{doc.name}</p>
                        <p className="text-xs text-muted-foreground">{doc.date} • {doc.type}</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">Скачать</Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default BorrowerDashboard;
