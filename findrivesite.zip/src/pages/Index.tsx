import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HeroSection from "@/components/landing/HeroSection";
import FeaturesSection from "@/components/landing/FeaturesSection";
import StatsSection from "@/components/landing/StatsSection";
import RequirementsSection from "@/components/landing/RequirementsSection";
import FAQSection from "@/components/landing/FAQSection";

const Index = () => (
  <div className="min-h-screen flex flex-col">
    <Header />
    <main className="flex-1">
      <HeroSection />
      <FeaturesSection />
      <StatsSection />
      <RequirementsSection />
      <FAQSection />
    </main>
    <Footer />
  </div>
);

export default Index;
