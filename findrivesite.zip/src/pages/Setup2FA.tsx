import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Shield, SkipForward, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const Setup2FAPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const role = (location.state as any)?.role || "investor";
  const [step, setStep] = useState<"intro" | "verify">("intro");
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleEnable = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-2fa-code");

      if (error) {
        toast({ title: "Ошибка", description: "Не удалось отправить код", variant: "destructive" });
        setLoading(false);
        return;
      }

      toast({ title: "Код отправлен", description: `Код подтверждения отправлен на ${data?.email || "вашу почту"}` });
      setStep("verify");
    } catch (err) {
      toast({ title: "Ошибка", description: "Не удалось отправить код", variant: "destructive" });
    }
    setLoading(false);
  };

  const handleVerify = async () => {
    if (code.length !== 6) {
      toast({ title: "Ошибка", description: "Введите 6-значный код", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("verify-2fa-code", {
        body: { code },
      });

      if (error || !data?.success) {
        toast({ title: "Ошибка", description: data?.error || "Неверный или просроченный код", variant: "destructive" });
        setLoading(false);
        return;
      }

      toast({ title: "2FA подключена!", description: "Двухфакторная авторизация успешно настроена" });
      navigate(role === "investor" ? "/dashboard/investor" : "/dashboard/borrower");
    } catch (err) {
      toast({ title: "Ошибка", description: "Не удалось проверить код", variant: "destructive" });
    }
    setLoading(false);
  };

  const handleResend = async () => {
    setLoading(true);
    try {
      await supabase.functions.invoke("send-2fa-code");
      toast({ title: "Код отправлен повторно", description: "Проверьте вашу почту" });
    } catch {
      toast({ title: "Ошибка", description: "Не удалось отправить код", variant: "destructive" });
    }
    setLoading(false);
  };

  const handleSkip = () => {
    navigate(role === "investor" ? "/dashboard/investor" : "/dashboard/borrower");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-section-alt p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-accent flex items-center justify-center mb-4">
            <Shield className="text-primary" size={32} />
          </div>
          <CardTitle className="font-heading">Двухфакторная авторизация</CardTitle>
          <CardDescription>
            Защитите свой аккаунт с помощью кода подтверждения на email
          </CardDescription>
        </CardHeader>
        <CardContent>
          {step === "intro" && (
            <div className="space-y-6">
              <div className="bg-accent rounded-lg p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <Mail className="text-primary mt-0.5" size={20} />
                  <div>
                    <p className="font-medium text-sm">Email-код</p>
                    <p className="text-sm text-muted-foreground">
                      При каждом входе вам будет отправлен 6-значный код на вашу электронную почту для подтверждения
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Button className="w-full" onClick={handleEnable} disabled={loading}>
                  {loading ? <Loader2 className="mr-2 animate-spin" size={16} /> : <Shield className="mr-2" size={16} />}
                  Подключить 2FA
                </Button>
                <Button variant="ghost" className="w-full text-muted-foreground" onClick={handleSkip}>
                  <SkipForward className="mr-2" size={16} />
                  Пропустить
                </Button>
              </div>
            </div>
          )}

          {step === "verify" && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground text-center">
                Мы отправили код подтверждения на вашу электронную почту. Введите его ниже.
              </p>

              <div>
                <Label>Код подтверждения</Label>
                <Input
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="000000"
                  maxLength={6}
                  className="text-center text-2xl tracking-widest font-mono"
                />
              </div>

              <Button className="w-full" onClick={handleVerify} disabled={loading}>
                {loading ? <Loader2 className="mr-2 animate-spin" size={16} /> : null}
                Подтвердить
              </Button>

              <div className="flex gap-2">
                <Button variant="ghost" className="flex-1" onClick={() => { setStep("intro"); setCode(""); }}>
                  Назад
                </Button>
                <Button variant="ghost" className="flex-1" onClick={handleResend} disabled={loading}>
                  Отправить повторно
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Setup2FAPage;
