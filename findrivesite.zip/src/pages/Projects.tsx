import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { RefreshCw, TrendingUp, Clock, AlertTriangle } from "lucide-react";

interface Project {
  id: string;
  name: string;
  description: string | null;
  company_name: string | null;
  target_amount: number;
  current_amount: number;
  interest_rate: number;
  duration_months: number;
  risk_level: string | null;
  status: string | null;
  image_url: string | null;
}

const riskColor = (risk: string | null) => {
  switch (risk?.toLowerCase()) {
    case "низкий": case "low": return "bg-green-100 text-green-800";
    case "высокий": case "high": return "bg-red-100 text-red-800";
    default: return "bg-yellow-100 text-yellow-800";
  }
};

const ProjectsPage = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [sheetUrl, setSheetUrl] = useState("");
  const { toast } = useToast();

  const fetchProjects = async () => {
    setLoading(true);
    const { data } = await supabase.from("projects").select("*").order("created_at", { ascending: false });
    setProjects((data as Project[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchProjects(); }, []);

  const handleSync = async () => {
    if (!sheetUrl) {
      toast({ title: "Ошибка", description: "Вставьте ссылку на Google Таблицу", variant: "destructive" });
      return;
    }
    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke("sync-google-sheet", {
        body: { sheet_url: sheetUrl },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      toast({ title: "Синхронизация завершена", description: `Обновлено проектов: ${data.synced} из ${data.total}` });
      await fetchProjects();
    } catch (e: any) {
      toast({ title: "Ошибка синхронизации", description: e.message, variant: "destructive" });
    } finally {
      setSyncing(false);
    }
  };

  const fmt = (n: number) => n.toLocaleString("ru-RU");

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-12">
          <div className="container">
            <motion.h1
              className="text-3xl lg:text-4xl font-heading font-bold text-center mb-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              Инвестиционные проекты
            </motion.h1>
            <p className="text-center text-muted-foreground mb-10 max-w-2xl mx-auto">
              Выберите проект для инвестирования. Данные обновляются из Google Таблицы.
            </p>

            <div className="bg-card border rounded-xl p-6 mb-10 max-w-2xl mx-auto">
              <h3 className="font-heading font-semibold mb-3">Синхронизация с Google Таблицей</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Вставьте ссылку на опубликованную Google Таблицу. Столбцы: Название, Описание, Компания, Сумма, Собрано, Ставка, Срок, Риск, Статус, Изображение.
              </p>
              <div className="flex gap-2">
                <Input
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  value={sheetUrl}
                  onChange={(e) => setSheetUrl(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={handleSync} disabled={syncing}>
                  <RefreshCw className={`mr-2 h-4 w-4 ${syncing ? "animate-spin" : ""}`} />
                  {syncing ? "Синхронизация..." : "Синхронизировать"}
                </Button>
              </div>
            </div>

            {loading ? (
              <div className="text-center py-20 text-muted-foreground">Загрузка проектов...</div>
            ) : projects.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground">
                Нет проектов. Добавьте данные в Google Таблицу и синхронизируйте.
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {projects.map((p, i) => {
                  const progress = p.target_amount > 0 ? Math.min(100, (p.current_amount / p.target_amount) * 100) : 0;
                  return (
                    <motion.div
                      key={p.id}
                      className="bg-card border rounded-xl overflow-hidden hover:shadow-lg transition-shadow"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      {p.image_url && (
                        <img src={p.image_url} alt={p.name} className="w-full h-40 object-cover" />
                      )}
                      <div className="p-5 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-heading font-bold text-lg leading-tight">{p.name}</h3>
                          <Badge className={riskColor(p.risk_level)} variant="secondary">
                            {p.risk_level || "средний"}
                          </Badge>
                        </div>

                        {p.company_name && (
                          <p className="text-sm text-muted-foreground">{p.company_name}</p>
                        )}

                        {p.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">{p.description}</p>
                        )}

                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div className="flex items-center gap-1.5">
                            <TrendingUp className="h-4 w-4 text-primary" />
                            <span>{p.interest_rate}% годовых</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock className="h-4 w-4 text-primary" />
                            <span>{p.duration_months} мес.</span>
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-muted-foreground">Собрано</span>
                            <span className="font-semibold">{fmt(p.current_amount)} / {fmt(p.target_amount)} ₽</span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div
                              className="bg-primary h-2 rounded-full transition-all"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        </div>

                        <Button className="w-full" size="sm">
                          Инвестировать
                        </Button>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default ProjectsPage;
