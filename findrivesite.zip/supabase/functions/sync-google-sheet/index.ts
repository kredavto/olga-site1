import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseUserClient = createClient(
      supabaseUrl,
      Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user }, error: userError } = await supabaseUserClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { sheet_url } = await req.json();

    if (!sheet_url) {
      return new Response(JSON.stringify({ error: "sheet_url is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Extract sheet ID from URL
    const match = sheet_url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (!match) {
      return new Response(JSON.stringify({ error: "Invalid Google Sheets URL" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const sheetId = match[1];
    const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;

    const csvResponse = await fetch(csvUrl);
    if (!csvResponse.ok) {
      return new Response(
        JSON.stringify({ error: "Failed to fetch Google Sheet. Make sure it's published (Файл → Опубликовать в интернете)." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const csvText = await csvResponse.text();
    const rows = parseCSV(csvText);

    if (rows.length < 2) {
      return new Response(JSON.stringify({ error: "Sheet is empty or has no data rows" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const headers = rows[0].map((h: string) => h.trim().toLowerCase());
    const dataRows = rows.slice(1).filter((r: string[]) => r.some((c: string) => c.trim()));

    const supabase = createClient(
      supabaseUrl,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    let synced = 0;
    for (let i = 0; i < dataRows.length; i++) {
      const row = dataRows[i];
      const rowId = `row_${i + 2}`;

      const getValue = (possibleNames: string[]) => {
        for (const name of possibleNames) {
          const idx = headers.indexOf(name);
          if (idx !== -1 && row[idx]?.trim()) return row[idx].trim();
        }
        return null;
      };

      const name = getValue(["название", "name", "проект", "project"]);
      if (!name) continue;

      const record = {
        sheet_row_id: rowId,
        name,
        description: getValue(["описание", "description", "desc"]),
        company_name: getValue(["компания", "company", "company_name"]),
        target_amount: parseFloat(getValue(["сумма", "целевая сумма", "target", "target_amount", "amount"]) || "0") || 0,
        current_amount: parseFloat(getValue(["собрано", "текущая сумма", "current", "current_amount", "raised"]) || "0") || 0,
        interest_rate: parseFloat(getValue(["ставка", "процент", "rate", "interest_rate", "interest"]) || "0") || 0,
        duration_months: parseInt(getValue(["срок", "месяцев", "duration", "months", "duration_months"]) || "12") || 12,
        risk_level: getValue(["риск", "уровень риска", "risk", "risk_level"]) || "средний",
        status: getValue(["статус", "status"]) || "активный",
        image_url: getValue(["изображение", "image", "image_url", "картинка", "фото"]),
      };

      const { error } = await supabase
        .from("projects")
        .upsert(record, { onConflict: "sheet_row_id" });

      if (!error) synced++;
    }

    return new Response(
      JSON.stringify({ success: true, synced, total: dataRows.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

function parseCSV(text: string): string[][] {
  const rows: string[][] = [];
  let current: string[] = [];
  let cell = "";
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (inQuotes) {
      if (char === '"' && text[i + 1] === '"') {
        cell += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        cell += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ",") {
        current.push(cell);
        cell = "";
      } else if (char === "\n" || (char === "\r" && text[i + 1] === "\n")) {
        current.push(cell);
        rows.push(current);
        current = [];
        cell = "";
        if (char === "\r") i++;
      } else {
        cell += char;
      }
    }
  }
  if (cell || current.length) {
    current.push(cell);
    rows.push(current);
  }
  return rows;
}
